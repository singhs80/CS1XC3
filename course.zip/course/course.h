/**
 * @file course.h
 * @author Shashank Singh
 * @date 2022-04-12
 * @brief Course library for managing courses, including
 *        course type definition and course function declarations
 */ 

#include "student.h"
#include <stdbool.h>
 
typedef struct _course 
{
  char name[100]; /** < Course name */
  char code[10]; /** < Course code */
  Student *students; /** < list of students and their data */
  int total_students; /** < number of students enrolled in the course */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


