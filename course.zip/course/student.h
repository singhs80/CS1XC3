/**
 * 
 * @file student.h
 * @author Shashank Singh
 * @date 2022-04-12
 * @brief Course library for managing students in a course, including
 *        student type definition and student function declarations.
 */ 

/**
 * Student type stores a student's first and last name, id, grades
 * and number of grades
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /** < student's first name */
  char last_name[50]; /** < student's last name */
  char id[11]; /** < student id, an array of characters */
  double *grades; /** < array of student's grades */
  int num_grades; /** < total number of grades */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
